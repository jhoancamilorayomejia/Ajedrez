MATRIZ_INTERFAZ = "matrices/matriz3.txt"
MATRIZ_BUSQUEDA = "matrices/matriz3.txt"
NODO_INICIO = 'E'
NODO_META = 'P'
